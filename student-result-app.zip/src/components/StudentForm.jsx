import React, { useState } from 'react';

export default function StudentForm({ initial, onSubmit, onBack }) {
  const [name, setName] = useState(initial?.name || "");
  const [section, setSection] = useState(initial?.section || "");
  const [marks, setMarks] = useState(initial?.marks || "");
  const [grade, setGrade] = useState(initial?.grade || "");

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ name, section, marks, grade });
  };

  return (
    <div>
      <h2>{initial ? "Edit Student" : "Add Student"}</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} /><br/><br/>
        <input placeholder="Section" value={section} onChange={e => setSection(e.target.value)} /><br/><br/>
        <input placeholder="Marks" value={marks} onChange={e => setMarks(e.target.value)} /><br/><br/>
        <input placeholder="Grade" value={grade} onChange={e => setGrade(e.target.value)} /><br/><br/>
        <button type="submit">Save</button>
        <button type="button" onClick={onBack}>Back</button>
      </form>
    </div>
  );
}
