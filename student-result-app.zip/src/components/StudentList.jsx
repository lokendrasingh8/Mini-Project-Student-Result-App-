import React from 'react';

export default function StudentList({ students, loadData, onAdd, onEdit, onDelete, onDetails }) {
  return (
    <div>
      <h2>Student List</h2>
      <button onClick={loadData}>Load Students</button>
      <button onClick={onAdd}>Add Student</button>

      <table border="1" cellPadding="5" style={{ marginTop: 10 }}>
        <thead>
          <tr>
            <th>Name</th><th>Section</th><th>Marks</th><th>Grade</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map(s => (
            <tr key={s.id}>
              <td>{s.name}</td>
              <td>{s.section}</td>
              <td>{s.marks}</td>
              <td>{s.grade}</td>
              <td>
                <button onClick={() => onDetails(s)}>View</button>
                <button onClick={() => onEdit(s)}>Edit</button>
                <button onClick={() => onDelete(s.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
