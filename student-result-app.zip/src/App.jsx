import React, { useState } from 'react';
import StudentList from './components/StudentList';
import StudentForm from './components/StudentForm';
import StudentDetails from './components/StudentDetails';
import { getStudents, addStudent, updateStudent, deleteStudent } from './services/studentService';

export default function App() {
  const [students, setStudents] = useState([]);
  const [screen, setScreen] = useState("list"); // list | form | details
  const [selected, setSelected] = useState(null);

  const loadData = async () => {
    const data = await getStudents();
    setStudents(data);
  };

  const handleAdd = () => { setSelected(null); setScreen("form"); };
  const handleEdit = (stu) => { setSelected(stu); setScreen("form"); };
  const handleDetails = (stu) => { setSelected(stu); setScreen("details"); };

  const handleDelete = async (id) => {
    await deleteStudent(id);
    alert("Student Deleted!");
  };

  const handleFormSubmit = async (data) => {
    if (selected) {
      await updateStudent(selected.id, data);
      alert("Student Updated!");
    } else {
      await addStudent(data);
      alert("Student Added!");
    }
    setScreen("list");
  };

  return (
    <div style={{ padding: 20 }}>
      {screen === "list" && (
        <StudentList
          students={students}
          loadData={loadData}
          onAdd={handleAdd}
          onEdit={handleEdit}
          onDelete={handleDelete}
          onDetails={handleDetails}
        />
      )}

      {screen === "form" && (
        <StudentForm initial={selected} onSubmit={handleFormSubmit} onBack={() => setScreen("list")} />
      )}

      {screen === "details" && (
        <StudentDetails student={selected} onBack={() => setScreen("list")} />
      )}
    </div>
  );
}
